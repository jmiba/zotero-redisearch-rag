# Changelog

## 0.6.8

- Adjust `citekey` sync policy: only sync note `citekey` back to Zotero `Extra` when a pinned citation-key line already exists.
- Always sync Zotero/Better BibTeX citekey changes into the Obsidian note, even when back-sync is disabled.
- Clarify docs for directional `citekey` sync behavior.

## 0.6.7

- Add `citekey` to two-way metadata sync between note frontmatter and Zotero items.
- Sync `citekey` to Zotero via `Extra` (`Citation Key: ...`) so Better BibTeX-pinned keys can be updated from Obsidian.
- Update docs to list synced metadata fields and clarify `citekey`/Better BibTeX behavior.

## 0.6.6

- Speed up Zotero import picker search for large libraries by reducing search payloads, adding query debouncing, and caching repeated queries.
- Restrict import picker search to top-level Zotero items and filter out non-importable/untitled results (`note`, `annotation`, `attachment`, and blank titles).

## 0.6.5

- Redis startup now prepends resolved Docker/compose binary directories to subprocess `PATH` so GUI-launched Obsidian can find Docker credential helpers.
- In settings, `Auto-assign Redis port` now appears above Redis override fields, and the override fields are disabled and greyed out when auto-assign is enabled.

## 0.6.4

- Publish a clean follow-up patch release so the Redis image pin and troubleshooting updates are included in release artifacts.

## 0.6.3

- Pin Redis Stack image to `docker.io/redis/redis-stack-server@sha256:798ab84d9f266936b034ab11c4d04a2b8e4b441884c5aa7d17ac951eefdf742a` to avoid `latest` drift.
- Clarify Redis startup troubleshooting with explicit file-sharing guidance and additional container startup diagnostics.

## 0.6.2

- Replace XPI verification with a download button that saves to your system Downloads folder.

## 0.6.1

- Include the Zotero companion XPI in release assets to ensure the plugin can install it.

## 0.6.0

- Image/rect annotations now embed as images in annotation callouts when available.
- Annotation fetch now requests `annotationImage` from Zotero and falls back if the API rejects the include.
- Annotation sync no longer sends `annotationText` for non-highlight/underline types to avoid Web API 400s.
- Added Zotero companion integration (settings + cached-only fetch) for image/ink annotations.
- Zotero companion settings now include install helpers and a status check button.
- Zotero companion add-on now ships with an update URL and `updates.json` manifest.
- Zotero companion settings can generate a token, verify the bundled XPI, and open Zotero Add-ons.
- Inline annotation citations now resolve to annotation blocks instead of missing `zrr-chunk` anchors.
- Docker autodetect no longer overwrites generic `docker`/`podman` values when starting Redis, keeping settings portable across OSes.

## 0.5.2

- Docker path autodetect no longer overwrites generic `docker`/`podman` settings with OS-specific absolute paths.

## 0.5.1

- Additionally to `~`, `$HOME`, and `%USERPROFILE%` in Python/Docker/Redis path fields, relative paths with separators now resolve from the user home (use `./` for vault-relative Redis paths).

## 0.5.0 Bugfix Release

- Annotation import now retries Web API lookups and warns when Web API access is missing.
- Tag syncing now re-converts normalized Obsidian tags back to space-separated Zotero tags to avoid duplicates.
- Retrieval now force-includes top annotation hits and marks annotation citations in chat.
- Settings now accept `~`, `$HOME`, and `%USERPROFILE%` in Python/Docker/Redis path fields for cross-OS portability.

## 0.4.9

- Doc index PDF paths now persist as vault-relative when possible.
- Zotero item picker now shows item type icons.
- Added a template placeholder and sync pipeline for Zotero annotations (two-way sync + Redis indexing).

## 0.4.8

- Section chunk markers now label sections explicitly and show the estimated page in parentheses.
- Section chunk badges display the section label with the estimated page number.
- Section chunk notes now include the section heading for readability.
- Metadata sync now includes DOI, publisher, place, issue, volume, pages, and item type.
- Zotero frontmatter keys now normalize to space-separated names (legacy underscore/hyphen/camel variants remain readable).
- Metadata sync now uses a single conflict modal and tracks a last-sync snapshot to reduce repeated prompts.
- Metadata sync snapshot is now stored in the cache instead of frontmatter.

## 0.4.7

- Better BibTeX citekeys: recognize pinned keys in Extra (bibtex/biblatex) and fall back to CSL `citation-key` when needed.
- Added `date_added` and `date_modified` template vars.

## 0.4.6

- Default reranker model updated to `BAAI/bge-reranker-v2-m3` for better multilingual retrieval.
- Internal refactor: extracted PDF sidebar, chunk marker, and attachment helpers into dedicated modules.

## 0.4.5

- Improved system prompt for footnote recognition in clean-up passes.
- Added a per-page OCR override setting and clarified OCR mode labels in settings.

## 0.4.4

- Added bidirectional YAML ↔ Zotero metadata sync (title, short title, date, abstract, tags, authors, editors) with per-field conflict prompts.
- Chat messages can now be copied or deleted individually (icon buttons).
- Docling logs now use UTC timestamps and include PID/doc context; noisy pypdf CMap warnings are summarized at end-of-run.
- Docling log file is cleared before each import.
- PaddleOCR-VL API retries now auto-split on 500 errors while honoring payload limits.
- Added support for context snippets in `index_redisearch.py`, allowing neighboring chunks to be included in embeddings.
- Introduced new command-line arguments for configuring context window size and character limits.
- Implemented functions to truncate context text and build context strings for better embedding context.
- Enhanced the main embedding logic to utilize the new context features.
- In `rag_query_redisearch.py`, added query expansion functionality to generate alternative queries.
- Implemented reranking of candidates based on a specified model, with options for maximum character limits.
- Improved retrieval logic to support broadening of search results based on metrics.
- Retrieval now supports configurable RRF blending and optional logging of top ranked chunks for tuning.
- Retrieval can now cap the number of chunks returned per document to improve diversity.
- Updated output structure to include expanded queries and reranking information.


## 0.4.3

- Implemented chunking of large pdfs to enable full pocessing via the PaddleOCR API.
- Updated text layer classification and quality assessment for PDFs.9
- Compatibility with [pdf++ plugin](https://github.com/RyotaUshio/obsidian-pdf-plus) for improved PDF handling.
- Compatibility with [Local IMages Plus plugin](https://github.com/Sergei-Korneev/obsidian-local-images-plus).
- Improved citation link generation in the chat assisstant responses.


## 0.4.2

- Images in PDFs are now extracted to the vault's attachment folder.

## 0.4.1

- Page-synchronous view of PDF in sidebar.
- Improved footnote conversion.
- Footer, header and page number removal from OCR/text-layer extraction.
- PaddleOCR API timeout handling.

## 0.4.0

- Import now resumes after a drop/rebuild when an embedding-dimension mismatch is detected, with clearer provider-error notices.
- Chat queries now handle embedding dimension mismatches by offering a drop/rebuild and retrying after a successful rebuild.
- Import/chat now surface embedding-provider failures encountered during rebuilds with clearer guidance.
- Import and Zotero group lookups now show a toast when the local Zotero API is unreachable.
- Docling OCR now supports PaddleOCR API endpoints (PaddleOCR-VL / PP-StructureV3) with engine selection and API key settings.
- Indexed text now labels image captions explicitly for retrieval.
- Python env now defaults to a shared user cache folder so multiple vaults can reuse it.
- Added a setting to choose between shared and per-vault Python env locations.
- Python path now defaults to blank and auto-detects interpreters when setting up the env.
- Plugin now detects an already-running Redis instance on startup (when auto-start is off) and notifies the user.

## 0.3.4

- Sync markers now render as styled badges in reading view (page/section + sync start/end).
- Added command to drop and rebuild the Redis index from cached chunks.
- Drop & rebuild now proceeds if the Redis index does not exist yet.
- Added a command to purge Redis chunk keys that have no cached item/chunk JSON.
- Doc index pruning now runs after reindexing/purge to remove stale entries.
- Embedding now splits long chunks into subchunks (multi-vector) while keeping display chunks intact.
- Embedding subchunk size/overlap is now configurable; section chunk size/overlap settings removed.
- Chunk end markers now render as badges in reading/live preview.
- Retrieval now auto-broadens before the LLM when context is weak (chunk count, context length, vector score, narrative filter).
- Indexing now derives text from a Markdown AST (table/list-aware) instead of flattening display Markdown.
- Page chunks now reflow wrapped OCR/text-layer lines while preserving headings/lists/tables.
- New command: delete the active Zotero note plus cached chunks/items to prevent recreation.
- Lexical retrieval now searches title/authors/tags/chunk tags and preserves Unicode tokens.
- New command: search the Redis index for a term (shows matching chunks/metadata).
- Exact lexical hits are kept even if strict content filters would drop them.
- Short queries now increase vector k and hyphenated terms are split for lexical matching.
- Index reindexing now detects embedding model/provider errors and prompts to drop & rebuild the Redis index.
- Indexing now auto-detects embedding dimensions to avoid mismatch loops after model changes.
- GPT-5 family models now omit non-default temperatures for OCR cleanup/tagging to avoid API errors.
- Reindexing now writes progress/error output to the log file when file logging is enabled.
- Import/reindex/chat now warn early when Redis is unreachable to avoid half-finished notes.
- Reindexing now uses existing chunk tags only (no tag regeneration).
- Embedding inputs are now truncated to avoid model context overflows during reindex.
- Reindex logs now include the current doc_id:chunk_id for embedding/index steps.
- Recreate-missing-notes now logs doc_id progress and indexer chunk progress.
- Tag sanitization now offers Obsidian-style cases (camel/pascal/snake/kebab) instead of a custom separator.
- Frontmatter now supports `aliases` built from citekey/short title/DOI (when present).
- Zotero picker now flags items without processable PDFs even when only non-PDF attachments exist.
- Notes now auto-repair missing frontmatter `doc_id` values using sync markers or cached index entries.
- Redis indexing now extracts years correctly from Zotero item dates.

## 0.3.3
- Tag-aware retrieval boosting and tag regeneration in the chunk editor.
- Tag sanitization options for Obsidian (replace spaces or camelCase).
- Note body template is now editable (with PDF/docling placeholders).
- Frontmatter template: clarified YAML-safe suffixes and added item link/citekey defaults.
- Fix: Chat title generation avoids incompatible OpenAI calls.
- LLM provider profiles: model lists refresh on profile switch; delete control moved into its own row.

## 0.3.2
- Hoverbar now shows Lucide icons and tooltips on all buttons.
- Hoverbar: clean-chunk and open-in-Zotero actions added.
- Chunk cleanup progress is now surfaced in the status bar.
- Frontmatter no longer emits empty tag entries when Zotero has no tags.

## 0.3.1
- Improved Python error handling and auto-opened Settings for environment fixes.
- Frontmatter `pdf_link` now stores raw Zotero deeplinks (no markdown wrapper).
- Release package now includes `CHANGELOG.md`.

## 0.3.0
- Cursor-anchored chunk toolbar with Tags, Indexed preview, and Exclude/Include.
- Excluded chunks are removed from Redis but preserved in chunk JSON for easy re-include.
- Indexed preview now matches Redis text (markdown-to-text normalization).
- Expanded Zotero frontmatter support: editors, tags, collections, book/journal fields, identifiers, and abstract.
- Frontmatter template editor restored in Settings.
- PDF handling: embed only when copied to the vault; frontmatter `pdf_link` always uses Zotero deep link.
- Metadata-aware embeddings and optional LLM chunk tagging for richer retrieval.
